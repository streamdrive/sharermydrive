<footer class="footer">
  <div class="container text-muted">
  	<div class="row">
  		<div class="col-xs-7 col-md-7">
      	<a href="https://www.facebook.com/YuuDrive/">Contact us</a> | <a href="/page/terms-conditions">Terms &amp; Conditions</a> | <a href="/page/privacy-policy">Privacy Policy</a> | <a href="/page/about">About us</a>
      </div>
    </div>
  </div>
</footer>
<script type="text/javascript" src="<?= base_url('assets/js/app.min.js?v3'); ?>"></script>
</body>
</html>