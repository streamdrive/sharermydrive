--------------
INDONESIA
--------------
Untuk sistem login ada dua metode
(1) pertama, dengan menggunakan prompt OAuth token dan copy paste token.
(2) kedua, login secara otomatis tanpa copy paste token.

Tutorial pembuatan API berikut merupakan untuk cara yang pertama (1).
jika ingin menggunakan cara yang kedua pembuatannya hampir sama, bedanya pada gambar ke 7 pilih Application type "Web Application"
dan isi Authorized redirect URIs dengan https://yourdomain.com/OAuth

Tapi untuk cara kedua anda harus memerlukan API Google yang sudah terverifikasi

--------------
EN
--------------
For the login system there are two methods
(1) first, by using the OAuth token prompt and copy paste the token.
(2) second, login automatically without copying the token.

The following tutorial on making API is for the first method (1).
if you want to use the second method of making almost the same, the difference in the 7th image select Application type "Web Application"
and fill in the Authorized redirect URIs by https://yourdomain.com/OAuth

but for the second way you must need an Google API that is already verified